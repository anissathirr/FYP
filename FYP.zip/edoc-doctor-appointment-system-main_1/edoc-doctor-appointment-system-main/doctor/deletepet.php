<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    if($_GET){
        //import database
        include("../connection.php");
        $id=$_GET["id"];
        //$result001= $database->query("select * from pethistory where appointmentid=$id;");
        //$pid=($result001->fetch_assoc())["pid"];
        $sql= $database->query("delete from pethistory where appointmentid='$id';");
        //$sql= $database->query("delete from patient where pid='$pid';");
        //print_r($pid);
        header("location: pethistory.php");
    }


?>