<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    if($_POST){
        //import database
        include("../connection.php");
        $petname=$_POST["petname"];
        $pid=$_POST["pid"];
        $description=$_POST["description"];
        $date=$_POST["date"];
        $time=$_POST["time"];
        $nextappointment=$_POST["nextappointment"];
        $amount=$_POST["amount"];
        $sql="insert into pethistory (petname,pid,description,appointmentdate,appointmenttime,nextappointment,amount) values ('$petname','$pid','$description','$date','$time','$nextappointment','amount');";
        $result= $database->query($sql);
        header("location: pethistory.php?action=session-added&description=$description");
        
    }


?>