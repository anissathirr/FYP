<?php
    // Import database
    include("../connection.php");

    if($_POST){
        // Retrieve all records from pethistory table
        $result = $database->query("SELECT * FROM pethistory");

        // Retrieve the value of the 'amount' parameter from the POST request
        $amount = $_POST['amount'];

        // Update the 'amount' column in the pethistory table
        $sql1 = "UPDATE pethistory SET amount='$amount'";
        $database->query($sql1);
    } else {
        $error = '3';
    }

    // Redirect the user to the pethistory.php page
    header("location: pethistory.php?action=edit&error=".$error."&id=".$id);
?>
