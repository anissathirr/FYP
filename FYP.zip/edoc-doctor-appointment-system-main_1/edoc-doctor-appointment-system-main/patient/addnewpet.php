<?php
session_start();

// Check if the user is logged in and has the appropriate user type
if(isset($_SESSION["user"]) && $_SESSION["user"] != "" && $_SESSION['usertype'] == 'p') {
    // Import database
    include("../connection.php");
    
    // Check if the form is submitted
    if($_POST) {
        $petid = $_POST['petid'];
        $type = $_POST['type'];
        $name = $_POST['name'];
        $breed = $_POST['breed'];
        
        // Get the user ID of the logged-in user
        $pid = $_SESSION["patient"];
        
        // Check if the pet already exists for the user
        $result = $database->query("SELECT * FROM pet WHERE petid='$petid' AND pid='$pid';");
        if($result->num_rows == 1) {
            $error = '1'; // Pet already exists for the user
        } else {
            $sql1 = "INSERT INTO pet(petid, pettype, petname, petbreed, pid) VALUES ('$petid', '$type', '$name', '$breed', '$pid');";
            $database->query($sql1);
            
            $error = '4'; // Pet added successfully
        }
    } else {
        $error = '3'; // Form not submitted
    }
} else {
    // Redirect the user to the login page if not logged in or incorrect user type
    header("location: ../login.php");
    exit();
}

header("location: pet.php?action=add&error=".$error."&petid=".$petid);
?>
