<?php
    // Import database
    include("../connection.php");

    $error = '';

    if ($_POST) {
        $result= $database->query("select * from pet");
        $type = $_POST['pettype'];
        $name = $_POST['petname'];
        $breed = $_POST['petbreed'];
        $id = $_POST['petid'];

        $result = $database->query("SELECT * FROM pet WHERE petid='$id';");
        if ($result->num_rows == 1) {
            $id2 = $result->fetch_assoc()["petid"];
        } else {
            $id2 = $id;
        }

        if ($id2 != $id) {
            $error = '1';
        } else {
            $sql1 = "UPDATE pet SET pettype='$type', petname='$name', petbreed='$breed' WHERE petid='$id'";
            $database->query($sql1);
            $error = '4';
        }
    } else {
        $error = '3';
    }

    header("location: pet.php?action=edit&error=".$error."&id=".$id);
    exit;
?>
